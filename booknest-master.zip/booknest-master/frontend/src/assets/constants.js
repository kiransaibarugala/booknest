const BACKEND_URL = "http://localhost:3000";

export {BACKEND_URL};
