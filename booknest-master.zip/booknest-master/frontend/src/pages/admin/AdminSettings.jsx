// import React from "react";

// const AdminSettings = () => {
//   return (
//     <div style={{ padding: "20px", maxWidth: "600px", margin: "auto" }}>
//       <h2 style={{ textAlign: "center", marginBottom: "20px" }}>
//         Admin Settings
//       </h2>

//       <form style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
//         <div>
//           <label style={{ fontWeight: "bold" }}>Admin Name:</label>
//           <br />
//           <input
//             type="text"
//             placeholder="Enter Admin Name"
//             style={{ width: "100%", padding: "10px" }}
//           />
//         </div>

//         <div>
//           <label style={{ fontWeight: "bold" }}>Email:</label>
//           <br />
//           <input
//             type="email"
//             placeholder="Enter Email"
//             style={{ width: "100%", padding: "10px" }}
//           />
//         </div>

//         <div>
//           <label style={{ fontWeight: "bold" }}>Change Password:</label>
//           <br />
//           <input
//             type="password"
//             placeholder="Enter New Password"
//             style={{ width: "100%", padding: "10px" }}
//           />
//         </div>

//         <button
//           type="submit"
//           style={{
//             padding: "12px",
//             backgroundColor: "#3498db",
//             color: "white",
//             border: "none",
//             cursor: "pointer",
//           }}
//         >
//           Save Changes
//         </button>
//       </form>
//     </div>
//   );
// };

// export default AdminSettings;
