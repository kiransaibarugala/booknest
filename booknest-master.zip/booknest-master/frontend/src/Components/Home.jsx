// // src/components/Home.jsx

// import React from "react";

const Home = () => {
  // return (
  //   <div style={{ textAlign: "center", marginTop: "50px" }}>
  //     <h1>📚 Welcome to BookNest 📚</h1>
  //     <p style={{ fontSize: "18px", color: "#555" }}>
  //       Your one-stop destination for exploring and buying books online.
  //     </p>
  //   </div>
  // );
};

export default Home;
